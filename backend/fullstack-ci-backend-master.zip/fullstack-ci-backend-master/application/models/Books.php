<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Books extends MY_Model {

	// public $_table = 'books';
	/*
	if table name referent model class name
	 */
	public function __construct()
	{
		parent::__construct();
	}
}

/* End of file Book.php */
/* Location: ./application/models/Book.php */